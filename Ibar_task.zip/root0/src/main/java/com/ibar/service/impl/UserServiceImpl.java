package com.ibar.service.impl;

import com.ibar.exception.WrongPermissionException;
import com.ibar.model.Role;
import com.ibar.model.User;
import com.ibar.repository.UserRepository;
import com.ibar.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Optional;

@Service
@SuppressWarnings("Duplicates")
public class UserServiceImpl implements UserService {

    public UserServiceImpl(UserRepository repository) {
        this.repository = repository;
    }

    private final UserRepository repository;

    @Override
    public List<User> getBlackList(Long currentUserId) {
        Optional<User> user = repository.findById(currentUserId);

        if (user.get().getRole().equals(Role.ADMIN)) {
            return repository.findByActiveIsFalse();
        } else {
            throw new WrongPermissionException("You don't have permission to proceed this operation");
        }

    }

    @Override
    public void activateUser(Long userId, Long currentUserId) {
        Optional<User> user = repository.findById(currentUserId);

        if (user.get().getRole().equals(Role.ADMIN)) {
            repository.changeUserStatus(true, userId);
        } else {
            throw new WrongPermissionException("You don't have permission to proceed this operation");
        }
    }

    @Override
    public User create(User user, Long currentUserId) {
        Optional<User> currentUser = repository.findById(currentUserId);

        if (currentUser.get().getRole().equals(Role.ADMIN)) {
            return repository.save(user);
        } else {
            throw new WrongPermissionException("You don't have permission to proceed this operation");
        }
    }

}