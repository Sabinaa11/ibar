package com.sinam.model;

public enum Role {
    USER, ADMIN;
}