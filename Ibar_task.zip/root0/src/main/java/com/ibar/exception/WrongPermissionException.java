package com.ibar.exception;

public class WrongPermissionException extends RuntimeException {

    public WrongPermissionException(String message) {
        super(message);
    }
}